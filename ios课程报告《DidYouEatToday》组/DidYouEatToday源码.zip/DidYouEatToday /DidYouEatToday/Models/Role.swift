//
//  Role.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/19.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation
import UIKit

//  人物属性因子
class PropertyFactor: NSObject, NSCoding {
    var MoralityFactor: Float?
    var IntelligenceFactor: Float?
    var PhysicalFactor: Float?
    var CharmFactor: Float?
    
    override init() {
        self.MoralityFactor = 0.0
        self.PhysicalFactor = 0.0
        self.IntelligenceFactor = 0.0
        self.CharmFactor = 0.0
    }
    init(moralityFactor: Float, physicalFactor: Float, intelligenceFactor: Float, charmFactor: Float) {
        self.MoralityFactor = moralityFactor
        self.PhysicalFactor = physicalFactor
        self.IntelligenceFactor = intelligenceFactor
        self.CharmFactor = charmFactor
    }
    func encode(with aCoder: NSCoder) {
        aCoder.encode(MoralityFactor, forKey: "MoralityFactor")
        aCoder.encode(IntelligenceFactor, forKey: "IntelligenceFactor")
        aCoder.encode(PhysicalFactor, forKey: "PhysicalFactor")
        aCoder.encode(CharmFactor, forKey: "CharmFactor")
    }
    required init?(coder aDecoder: NSCoder) {
        MoralityFactor = aDecoder.decodeObject(forKey: "MoralityFactor") as? Float
        IntelligenceFactor = aDecoder.decodeObject(forKey: "IntelligenceFactor") as? Float
        PhysicalFactor = aDecoder.decodeObject(forKey: "PhysicalFactor") as? Float
        CharmFactor = aDecoder.decodeObject(forKey: "CharmFactor") as? Float
    }
    //  属性相加
    func apprendFactor(factor: PropertyFactor) -> PropertyFactor {
        var result = PropertyFactor()
        result.MoralityFactor = self.MoralityFactor! + factor.MoralityFactor!
        result.PhysicalFactor = self.PhysicalFactor! + factor.PhysicalFactor!
        result.IntelligenceFactor = self.IntelligenceFactor! + factor.IntelligenceFactor!
        result.CharmFactor = self.CharmFactor! + factor.CharmFactor!
        return result
    }
    func copySelf() -> PropertyFactor {
        return PropertyFactor(moralityFactor: self.MoralityFactor!, physicalFactor: self.PhysicalFactor!, intelligenceFactor: self.IntelligenceFactor!, charmFactor: self.CharmFactor!)
    }
    // 获取根目录
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    // 增加子目录
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("factorList")
    
}
//  人物属性
class RoleProperty: NSObject, NSCoding {
    var Morality: Int?
    var Intelligence: Int?
    var Physical: Int?
    var Charm: Int?
    var Energy:Int?
    var PocketMoney: Int?
    
    init(Morality: Int = 0, Intelligence: Int = 0, Physical: Int = 0, Charm: Int = 0, Energy:Int = 0, PocketMoney: Int = 0) {
        self.Morality = Morality
        self.Intelligence = Intelligence
        self.Physical = Physical
        self.Charm = Charm
        self.Energy = Energy
        self.PocketMoney = PocketMoney
    }
    func encode(with aCoder: NSCoder) {
        aCoder.encode(Morality, forKey: "Morality")
        aCoder.encode(Intelligence, forKey: "Intelligence")
        aCoder.encode(Physical, forKey: "Physical")
        aCoder.encode(Charm, forKey: "Charm")
        aCoder.encode(Energy, forKey: "Energy")
        aCoder.encode(PocketMoney, forKey: "PocketMoney")
    }
    required init?(coder aDecoder: NSCoder) {
        Morality = aDecoder.decodeObject(forKey: "Morality") as? Int
        Intelligence = aDecoder.decodeObject(forKey: "Intelligence") as? Int
        Physical = aDecoder.decodeObject(forKey: "Physical") as? Int
        Charm = aDecoder.decodeObject(forKey: "Charm") as? Int
        Energy = aDecoder.decodeObject(forKey: "Energy") as? Int
        PocketMoney = aDecoder.decodeObject(forKey: "PocketMoney") as? Int
    }
    func isBetterThan(property: RoleProperty) -> Bool {
        if (self.Morality! < property.Morality!)||(self.Intelligence! < property.Intelligence!)||(self.Physical! < property.Physical!)||(self.Charm! < property.Charm!) {
            return false
        }
        return true
    }
    
    func apprend(property: RoleProperty) -> RoleProperty {
        return RoleProperty(Morality: self.Morality! + property.Morality!, Intelligence: self.Intelligence! + property.Intelligence!, Physical: self.Physical! + property.Physical!, Charm: self.Charm! + property.Charm!, Energy: addEnergy(value: property.Energy!), PocketMoney: self.PocketMoney! + property.PocketMoney!)
    }
    //  (1 + factor)
    func multiplyFactor(factor: PropertyFactor) {
        self.Morality = Morality! + Int(Float(Morality!) * factor.MoralityFactor!)
        self.Intelligence = Intelligence! + Int(Float(Intelligence!) * factor.IntelligenceFactor!)
        self.Physical = Physical! + Int(Float(Physical!) * factor.PhysicalFactor!)
        self.Charm = Charm! + Int(Float(Charm!) * factor.CharmFactor!)
    }
    //  随机设定角色的德智体美属性
    func randomPropertyValue(startValue: Int = 10, endValue: Int = 100) {
        let scope = endValue - startValue
        self.Morality = Int(arc4random_uniform(UInt32(scope))) + startValue
        self.Intelligence = Int(arc4random_uniform(UInt32(scope))) + startValue
        self.Physical = Int(arc4random_uniform(UInt32(scope))) + startValue
        self.Charm = Int(arc4random_uniform(UInt32(scope))) + startValue
    }
    func addEnergy(value: Int) -> Int {
        var result = self.Energy! + value
        if result > 100 {
            result = 100
        }
        return result
    }
    func copySelf() -> RoleProperty {
        return RoleProperty(Morality: self.Morality!, Intelligence: self.Intelligence!, Physical: self.Physical!, Charm: self.Charm!, Energy: self.Energy!, PocketMoney: self.PocketMoney!)
    }
    
    // 获取根目录
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    // 增加子目录
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("propertyList")
    
}



class Role: NSObject, NSCoding {
    var myName: String?
    var myAge: Int?
    var mySex: Int?
    var myProperty: RoleProperty?
    var myFactor: PropertyFactor?
    var myLiveDay: SchoolTime?
    var myHobbies: [Hobby]?
    
    init(name: String, age: Int, sex: Int, hobbies: [Hobby]) {
        super.init()
        self.myName = name
        self.myAge = age
        self.mySex = sex
        self.myHobbies = hobbies
        self.myProperty = RoleProperty()
        self.myFactor = PropertyFactor()
        self.myLiveDay = SchoolTime()
        self.myHobbies = hobbies
        setRoleProperty()
    }
    func encode(with aCoder: NSCoder) {
        aCoder.encode(myName, forKey: "myName")
        aCoder.encode(myAge, forKey: "myAge")
        aCoder.encode(mySex, forKey: "mySex")
        aCoder.encode(myProperty, forKey: "myProperty")
        aCoder.encode(myFactor, forKey: "myFactor")
        aCoder.encode(myLiveDay, forKey: "myLiveDay")
        aCoder.encode(myHobbies, forKey: "myHobbies")
    }
    required init?(coder aDecoder: NSCoder) {
        myName = aDecoder.decodeObject(forKey: "myName") as? String
        myAge = aDecoder.decodeObject(forKey: "myAge") as? Int
        mySex = aDecoder.decodeObject(forKey: "mySex") as? Int
        myProperty = aDecoder.decodeObject(forKey: "myProperty") as? RoleProperty
        myFactor = aDecoder.decodeObject(forKey: "myFactor") as? PropertyFactor
        myLiveDay = aDecoder.decodeObject(forKey: "myLiveDay") as? SchoolTime
        myHobbies = aDecoder.decodeObject(forKey: "myHobbies") as? [Hobby]
    }
    //  初始化人物属性
    func setRoleProperty() {
        for hobby in myHobbies! {
            self.myFactor = myFactor!.apprendFactor(factor: hobby.hobbyFactor!)
        }
        self.myProperty?.randomPropertyValue()
        self.myProperty?.PocketMoney = 1000
        self.myProperty?.Energy = 100
    }
    
    //  人物属性更改
    func addRoleCharacterValue(property: RoleProperty) {
        self.myProperty = self.myProperty?.apprend(property: property)
    }
    
    //  饥饿值更改
    func addRoleEnergyValue(value: Int) -> Bool {
        self.myProperty!.Energy! += value
        if self.myProperty!.Energy! <= 0 {
            print("饿到昏倒，被送人医院，零用钱减150")
            self.addPocketMoney(value: -150)
            self.myProperty!.Energy = 0
            return true
        }
        else if self.myProperty!.Energy! >= 100 {
            self.myProperty!.Energy = 100
        }
        return false
    }
    //  零用钱更改
    func addPocketMoney(value: Int) {
        self.myProperty!.PocketMoney! += value
        if self.myProperty!.PocketMoney! < 0 {
            print("零用钱花完了")
            self.myProperty!.PocketMoney! = 0
        }
    }
    //  更改角色性别
    func setRoleSex(sex: Int) {
        self.mySex = sex
    }
    //  设置角色爱好
    func setRoleHobbies(hobbies: [Hobby]) -> Bool {
        self.myHobbies = hobbies
        return true
    }
    func getRoleFactor() -> PropertyFactor {
        return self.myFactor!
    }
    
    
    // 获取根目录
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    // 增加子目录
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("role")
    
    func getHobbyName() -> String {
        let count = myHobbies?.count
        var hobbyDetail = "爱好: "
        
        if count == 0 {
            hobbyDetail = "爱好: 无"
        }
        else {
            for index in 0..<count! {
                hobbyDetail = hobbyDetail + myHobbies![index].hobbyName!
                if index != count!-1 {
                    hobbyDetail = hobbyDetail + " | "
                }
            }
        }
        
        return hobbyDetail
    }
    
    func printDetail() {
        print("名字： " + self.myName!)
        print("年龄： \(self.myAge!)")
        print("性别： \(self.mySex!)")
        print("体力： \(self.myProperty!.Energy!)")
        print("零花钱： \(self.myProperty!.PocketMoney!)")
        for hobby in myHobbies! {
            print("爱好： \(hobby.hobbyName!)")
        }
        
        print("属性：\n德\t智\t体\t美 \n\(self.myProperty!.Morality!)\t\(self.myProperty!.Intelligence!)\t\(self.myProperty!.Physical!)\t\(self.myProperty!.Charm!) " )
        print("因子：\n德\t智\t体\t美 \n\(self.myFactor!.MoralityFactor!)\t\(self.myFactor!.IntelligenceFactor!)\t\(self.myFactor!.PhysicalFactor!)\t\(self.myFactor!.CharmFactor!) " )
        
    }
}
