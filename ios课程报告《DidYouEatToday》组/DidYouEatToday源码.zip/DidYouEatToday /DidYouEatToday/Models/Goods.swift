//
//  Goods.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/10.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation
import UIKit

class Goods {
    var type: String?
    var name: String?
    var goodsIcon: UIImage?
    var property: RoleProperty?
    
    init(name: String?,energy:Int,imagepath:String,morality:Int,intelligence:Int,physical:Int,charm:Int,pocketmoney:Int){
        self.name = name
        self.goodsIcon = nil
        //self.acImage = UIImage(imageLiteralResourceName: imagepath)
        self.property = RoleProperty(Morality: morality, Intelligence:  intelligence, Physical:  physical, Charm:  charm, Energy: energy, PocketMoney:  pocketmoney)
    }
}
