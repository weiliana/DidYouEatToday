//
//  food.swift
//  DidYouEatToday
//
//  Created by ASCII on 2019/11/12.
//  Copyright © 2019 zeror. All rights reserved.
//

import Foundation
import UIKit

class Food:NSObject, NSCoding {
    func encode(with aCoder: NSCoder) {
        aCoder.encode(price,forKey: "priceKey")
        aCoder.encode(name,forKey: "nameKey")
        aCoder.encode(id, forKey: "idKey")
        aCoder.encode(satisfy, forKey: "satisfyKey")
        aCoder.encode(happiness, forKey: "happinessKey")
        aCoder.encode(health, forKey: "healthKey")
        aCoder.encode(foodAvatar, forKey: "avatarKey")
        aCoder.encode(detial,forKey: "detialKey")
        aCoder.encode(eaten, forKey: "eatenKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        price = aDecoder.decodeObject(forKey: "priceKey") as? Int
        name = aDecoder.decodeObject(forKey: "nameKey") as? String
        id = aDecoder.decodeObject(forKey: "idKey") as? Int
        satisfy = aDecoder.decodeObject(forKey: "satisfyKey") as? Int
        happiness = aDecoder.decodeObject(forKey: "happinessKey") as? Int
        health = aDecoder.decodeObject(forKey: "healthKey") as? Int
        foodAvatar = aDecoder.decodeObject(forKey: "avatarKey") as? UIImage
        detial = aDecoder.decodeObject(forKey: "detialKey") as? String
        eaten = aDecoder.decodeObject(forKey: "eatenKey") as? Bool
    }
    
    init(_id:Int,_name:String?,_price:Int,_satisfy:Int!,_happiness:Int!,_health:Int!,_detial:String) {
        name = _name
        id = _id
        satisfy = _satisfy
        happiness = _happiness
        health = _health
        detial = _detial
        price=_price
        
    }
    
    var price:Int?
    var name:String?
    var id:Int?
    var satisfy:Int?
    var happiness:Int?
    var health:Int?
    var foodAvatar:UIImage?
    var detial:String?
    var eaten:Bool? = false
    
    
    static let documentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    
    static let archiveURL = documentsDirectory.appendingPathComponent("foodList")
    
    
    
}



