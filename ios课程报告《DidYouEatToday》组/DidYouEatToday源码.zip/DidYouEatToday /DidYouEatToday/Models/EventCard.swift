//
//  EventModel.swift
//  DidYouEatToday
//
//  Created by Apple on 2019/11/19.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation
import UIKit

class EventCard: NSObject,NSCoding{
    var eventName: String?//事件名
    var eventDescription: String?//事件描述
    var eventLeftProperty: RoleProperty?
    var eventRightProperty: RoleProperty?
    var eventAvatar: UIImage?//事件图片
    var eventSelectLeft: String?//事件选项1按钮
    var eventSelectRight: String?//事件选项2按钮
    var eventLeftResult: String?//事件选项1结果
    var eventRightResult: String?//事件选项2结果
    var eventType: String?//事件类型
    
    init(eventName:String?,eventDescription:String?,eventAvatar:UIImage?,eventLeftProperty: RoleProperty,eventRightProperty: RoleProperty,eventSelectLeft:String?,eventSelectRight:String?,eventLeftResult:String?,eventRightResult:String?,eventType:String?) {
        self.eventName = eventName
        self.eventDescription = eventDescription
        self.eventAvatar = eventAvatar
        self.eventLeftProperty = eventLeftProperty
        self.eventRightProperty = eventRightProperty
        self.eventSelectLeft = eventSelectLeft
        self.eventSelectRight = eventSelectRight
        self.eventLeftResult = eventLeftResult
        self.eventRightResult = eventRightResult
        self.eventType = eventType
    }
    override init() {
        self.eventName = ""
        self.eventDescription = ""
        self.eventAvatar = nil
        self.eventSelectLeft = ""
        self.eventSelectRight = ""
        self.eventLeftResult = ""
        self.eventRightResult = ""
        self.eventType = ""
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(eventName,forKey: "nameKey")
        aCoder.encode(eventDescription,forKey: "descriptionKey")
        aCoder.encode(eventAvatar,forKey: "avatarKey")
        aCoder.encode(eventLeftProperty,forKey: "leftPropertyKey")
        aCoder.encode(eventRightProperty,forKey: "rightPropertyKey")
        aCoder.encode(eventSelectLeft,forKey: "selectLeftKey")
        aCoder.encode(eventSelectRight,forKey: "selectRightKey")
        aCoder.encode(eventLeftResult,forKey: "eventLeftResult")
        aCoder.encode(eventRightResult,forKey: "eventRightResult")
        aCoder.encode(eventType,forKey: "typeKey")
    }
    required init?(coder aDecoder: NSCoder) {
        eventName = aDecoder.decodeObject(forKey: "namekey") as? String
        eventDescription = aDecoder.decodeObject(forKey: "descriptionKey") as? String
        eventAvatar = aDecoder.decodeObject(forKey: "avatarKey") as? UIImage
        eventLeftProperty = aDecoder.decodeObject(forKey: "leftPropertyKey") as? RoleProperty
        eventRightProperty = aDecoder.decodeObject(forKey: "rightPropertyKey") as? RoleProperty
        eventSelectLeft = aDecoder.decodeObject(forKey: "selectLeftKey") as? String
        eventSelectRight = aDecoder.decodeObject(forKey: "selectRightKey") as? String
        eventLeftResult = aDecoder.decodeObject(forKey: "eventLeftResult") as? String
        eventRightResult = aDecoder.decodeObject(forKey: "eventRightResult") as? String
        eventType = aDecoder.decodeObject(forKey: "typeKey") as? String
    }
    
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("eventCardList")
}

//  事件卡牌的相关使用
class EventCardFactory {
    var eventCards: [EventCard] = [EventCard]()
    
    init(isLoad: Bool = true) {
        if isLoad {
            let cardsData = loadCardsFile()
            eventCards = cardsData!
        }
        else {
           //   新的事件牌组
            createNewCards()
            saveCardsFile()
        }
    }
    
    func createNewCards() {
        eventCards.append(EventCard(eventName: "", eventDescription: "你去吃早餐的时候，在路上遇到了一只流浪猫，它趴着草地上好像在注视着什么，你很好奇它在看什么...", eventAvatar: nil, eventLeftProperty: RoleProperty(Morality: 22, Intelligence: 14, Physical: 9, Charm: 16, Energy: 0, PocketMoney: 0), eventRightProperty: RoleProperty(Morality: -8, Intelligence: -12, Physical: 0, Charm: -10, Energy: 0, PocketMoney: 0), eventSelectLeft: "靠近", eventSelectRight: "走开", eventLeftResult: "流浪猫看到你靠近后迅速跑掉了，不过你发现了远处的草丛里有一只从没见过的小黑猫。", eventRightResult: "你走开后，内心一直很好奇那里会有什么，感觉错过了什么。", eventType: ""))
        eventCards.append(EventCard(eventName: "", eventDescription: "你昨晚做了一个奇怪的梦，梦见你未来会发生一件影响你一生的事情，你觉得要做些什么...", eventAvatar: nil, eventLeftProperty: RoleProperty(Morality: 10, Intelligence: 24, Physical: 9, Charm: 6, Energy: 0, PocketMoney: 0), eventRightProperty: RoleProperty(Morality: 10, Intelligence: 12, Physical: 20, Charm: 8, Energy: 0, PocketMoney: 0), eventSelectLeft: "记下", eventSelectRight: "忘掉", eventLeftResult: "未来的你会发现，当初记下的笔记会预示着你成功地躲过了一次空难事件。", eventRightResult: "你觉得这并不重要，刷完牙就出门买早餐了，完全忘记了梦的细节。", eventType: ""))
    }
    
    func takeCard() -> EventCard {
        let index = Int(arc4random_uniform(UInt32(eventCards.count - 1)))
        return eventCards[index]
    }
    func takeHospitalCard() -> EventCard {
        let porperty = RoleProperty(Morality: 0, Intelligence: 0, Physical: 0, Charm: 0, Energy: 100, PocketMoney: -150)
        let result = "最后你不得不支付了150块的医疗费，但你得到了充足的休息，感觉身体恢复到了原来的状态。"
        
        return EventCard(eventName: "", eventDescription: "饿到昏倒，被人送进医院补充了葡萄糖", eventAvatar: nil, eventLeftProperty: porperty, eventRightProperty: porperty, eventSelectLeft: "确定", eventSelectRight: "确定",eventLeftResult: result, eventRightResult: result, eventType: "")
    }
    func takeStarveCard() -> EventCard {
        let result = "最后你因为没有足够的钱来继续你的学业，你只好辍学去打工，经过多年的努力和拼搏，你最终开了你人生中的第一家餐厅，当上了餐厅的老板。"
        return EventCard(eventName: "", eventDescription: "饿到昏倒，被人送进医院补充了葡萄糖", eventAvatar: nil, eventLeftProperty: RoleProperty(), eventRightProperty: RoleProperty(), eventSelectLeft: "确定", eventSelectRight: "确定",eventLeftResult: result, eventRightResult: result, eventType: "")
    }
    
    func takeGraduateCard(roleProperty: RoleProperty) -> EventCard {
        let porperty1 = RoleProperty(Morality: 500, Intelligence: 2400, Physical: 1800, Charm: 400, Energy: 0, PocketMoney: 0)
        var result1 = ""
        let result2 = "看着周围同学为读研而做准备，你毅然决然地投入到了就业大军中。经过多年的拼搏打拼，最终你成为了一家公司的技术总监。"
        
        let isGraduate = roleProperty.isBetterThan(property: porperty1)
        if isGraduate {
            result1 = "经过你的不懈努力，你终于成功考研上岸，成为了一名研究生。多年后你继续读博，发表了多篇期刊论文，取得了重大的研究成果，最终成为了一名研究院的院士。"
        }
        else{
            result1 = "尽管你为考研做了很多准备，但你最后还是遗憾落榜了。面对生活的压力，你放弃了继续考研，选择了进入了职场，成为了一家公司的人事部经理。"
        }
        
        
        return EventCard(eventName: "", eventDescription: "快到毕业季了，很多同学都选择继续读研，你经过深思熟虑后，你做的决定是：", eventAvatar: nil, eventLeftProperty: RoleProperty(), eventRightProperty: RoleProperty(), eventSelectLeft: "考研", eventSelectRight: "就业",eventLeftResult: result1, eventRightResult: result2, eventType: "")
    }
    
    func saveCardsFile(){
        let success = NSKeyedArchiver.archiveRootObject(eventCards, toFile: EventCard.ArchiveURL.path)
        if !success {
            print("EventCards save failed")
        }
    }
    
    func loadCardsFile() -> [EventCard]? {
        return (NSKeyedUnarchiver.unarchiveObject(withFile: EventCard.ArchiveURL.path) as? [EventCard])
    }
    
}
