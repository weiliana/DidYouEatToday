//
//  Hobby.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/26.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation

class Hobby: NSObject, NSCoding {
    var hobbyName: String?
    var hobbyAvatar: String?
    var hobbyFactor: PropertyFactor?
    
    init(name: String, avatar: String?, factor: PropertyFactor) {
        self.hobbyName = name
        self.hobbyAvatar = avatar
        self.hobbyFactor = factor
    }
    func encode(with aCoder: NSCoder) {
        aCoder.encode(hobbyName, forKey: "hobbyName")
        aCoder.encode(hobbyAvatar, forKey: "hobbyAvatar")
        aCoder.encode(hobbyFactor, forKey: "hobbyFactor")
    }
    required init?(coder aDecoder: NSCoder) {
        hobbyName = aDecoder.decodeObject(forKey: "hobbyName") as? String
        hobbyAvatar = aDecoder.decodeObject(forKey: "hobbyAvatar") as? String
        hobbyFactor = aDecoder.decodeObject(forKey: "hobbyFactor") as? PropertyFactor
    }
    
    // 获取根目录
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    // 增加子目录
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("hobbyList")
}

class HobbyFactory {
    static let myHobbyName = ["编程","弹钢琴","下棋", "跑步", "玩游戏"]
    static let myHobbyImage = ["icon-coding","icon-piano","icon-chart","icon-running","icon-playGame"]
    
    static let myHobbyFactor: [[Float]] = [[0.3, 0.7, 0.2, 0.1],
                        [0.4, 0.2, 0.2, 0.7],
                        [0.3, 0.5, 0.3, 0.2],
                        [0.1, 0.1, 0.8, 0.4],
                        [0.2, 0.5, 0.3, 0.3]]
    
    static func createHobbies() -> [Hobby] {
        var hobbies: [Hobby] = [Hobby]()
        for index in 0..<myHobbyName.count{
            let hobby = Hobby(name: myHobbyName[index], avatar: myHobbyImage[index], factor: PropertyFactor(moralityFactor: myHobbyFactor[index][0], physicalFactor: myHobbyFactor[index][1], intelligenceFactor: myHobbyFactor[index][2], charmFactor: myHobbyFactor[index][3]))
            hobbies.append(hobby)
        }
        return hobbies
    }
}
