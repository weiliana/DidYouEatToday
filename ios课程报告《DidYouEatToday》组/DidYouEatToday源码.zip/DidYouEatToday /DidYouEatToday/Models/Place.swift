//
//  Map.swift
//  DidYouEatToday
//
//  Created by ASCII on 2019/12/3.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation
import UIKit


class Place {
    var name: String?
    var placeAvatar: UIImage?
    var detial: String
    var energy: Int?
    var openTime: Int?
    
    init(name:String,energy:Int,openTime: Int, placeAvatar:String,detial:String) {
        
        //let image = UIImage(imageLiteralResourceName: placeAvatar)
        self.openTime = openTime
        self.name = name
        //self.placeAvatar = image
        self.detial = detial
        self.energy = energy
    }
}
