//
//  FoodWarehouse.swift
//  DidYouEatToday
//
//  Created by ASCII on 2019/11/12.
//  Copyright © 2019 zeror. All rights reserved.
//

import Foundation

class FoodWarehouse {
    
    static let singleton = FoodWarehouse()
    
    private init() {
        initFoodList()
    }
    
    var foodList:[Food]=[Food]()
    
    //初始化（加载）食物仓库，数据持久化储存，吃过的食物新的游戏开始也可见详情
    func initFoodList(){
        
        //撤销注释后可数据持久化
        /*
         let data=loadFoodFlie()
        if data == nil{
        */
        
        //食物列表初始化，使用.appen（）增加食物类型
        
        foodList.append(Food(_id: 0, _name: "food", _price: 10, _satisfy: 10, _happiness: 10, _health: 10, _detial: "tastes well"))
        
        /*
         
         }
        else{
            foodList.append(contentsOf:data!)
        }
         */
    }
    
    func getFoodById(id:Int) -> Food {
        return foodList[id]
    }
    
    //食用后改为已经吃过
    func eat(id:Int) -> Void{
        foodList[id].eaten = true
        //数据持久化
        saveFoodFile()
    }
    
    func saveFoodFile() {
        let success = NSKeyedArchiver.archiveRootObject(foodList, toFile: Food.archiveURL.path)
        if !success{
            print("Failed")
        }
    }
    
    func loadFoodFlie() -> [Food]? {
        return (NSKeyedUnarchiver.unarchiveObject(withFile: Food.archiveURL.path) as? [Food])
    }
    
}
