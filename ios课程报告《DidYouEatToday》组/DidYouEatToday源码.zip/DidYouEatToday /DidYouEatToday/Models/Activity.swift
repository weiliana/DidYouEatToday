//
//  activity.swift
//  DidYouEatToday
//
//  Created by Apple on 2019/11/19.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation
import UIKit

class Activity :NSObject,NSCoding{
    
    var type: String?
    var name: String?
    //var energy = 0
    var activityIcon: UIImage?
    var property: RoleProperty?
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("activityList")
    
    init(name: String?,energy:Int,imagepath:String,morality:Int,intelligence:Int,physical:Int,charm:Int,pocketmoney:Int){
        self.name = name
        //self.energy = energy
        self.activityIcon = nil
        //self.acImage = UIImage(imageLiteralResourceName: imagepath)
        self.property = RoleProperty(Morality: morality, Intelligence:  intelligence, Physical:  physical, Charm:  charm, Energy: energy, PocketMoney:  pocketmoney)
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "nameKey")
        //aCoder.encode(energy, forKey: "energyKey")
        aCoder.encode(activityIcon, forKey: "imageKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "nameKey")as? String
        //energy = aDecoder.decodeObject(forKey: "energyKey")as! Int
        activityIcon = aDecoder.decodeObject(forKey: "imageKey")as? UIImage
    }
}

