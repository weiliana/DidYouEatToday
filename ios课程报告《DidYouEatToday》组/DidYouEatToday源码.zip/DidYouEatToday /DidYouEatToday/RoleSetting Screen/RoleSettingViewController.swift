//
//  RoleSettingViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/17.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class RoleSettingViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var roleSex: Int?
    var role: Role?
    
    var hobbyBox: [Hobby] = [Hobby]()
    var hobbySelected: [Hobby] = [Hobby]()
    
    let nameBoxMale: [String] = ["陈寻","乔康","白乔","顾海诚","章远帆","江辰","路星河","陆昂","龙华清","金志学","张英彦","孙修远","尹信鸿","梁恺乐","许建安","沈阳炎","丁德义","秦宏大","韩开诚","顾苑杰","蔡阳曜","谢晟睿","韩承宣","龙锐意","毛烨磊","薛伟兆","薛经亘","龙星光","孔安民","汤苑杰","段子石","金弘盛","宋星河","贺兴邦","蒋天元","邓德元","顾刚毅","吴哲茂","杨文林","顾兴发","范同济","熊嘉茂","邹弘文","汤国源","邵茂实","潘飞雨","刘正雅","江阳华","魏兴平","程承泽"]
    let nameBoxFemale: [String] = ["方茴","梁烨","林嘉","何洛","陈希","傅司徒","林杨","王丹萱","孟雨柏","魏语燕","郝怡和","谭山芙","韩秋珊","邱子琳","钱静秀","谭尔容","余新妹","郝妍凌","郑桂芝","孟姮娥","夏书文","林慕思","易鸾瑶","田萦心","冯绮美","周乐怡","高若烟","任倩冰","崔念珍","谢思琪","贾念薇","潘悦恺","高子帆","程月桃","彭蕙若","曹晓枫","史霞绮","范莉娜","潘山彤","尹子舒","袁雅可","杜兰芳","王映萱","崔雪婧","刘悦远","郭颐真"]
    
    @IBOutlet weak var hobbyTableView: UITableView!
    @IBOutlet weak var roleNameText: UITextField!
    
    @IBAction func backButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func backButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    
    //  根据性别随机产生名字
    @IBAction func randomCreateNameButtonClicked(_ sender: Any) {
        roleNameText.text = randomName()
    }
    
    func randomName() -> String {
        var name: String = ""
        if roleSex == 1 {
            let nameBoxSize = nameBoxMale.count - 1
            let order = Int(arc4random_uniform(UInt32(nameBoxSize)))
            name = nameBoxMale[order]
        }
        else if roleSex == 0 {
            let nameBoxSize = nameBoxFemale.count - 1
            let order = Int(arc4random_uniform(UInt32(nameBoxSize)))
            name = nameBoxFemale[order]
        }
        return name
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hobbyTableView.rowHeight = 80
        roleNameText.text = randomName()
        hobbyBox = HobbyFactory.createHobbies();
        print(hobbyBox.count)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return hobbyBox.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "hobbyCell", for: indexPath) as! HobbyTableViewCell
        cell.hobbyName.text = hobbyBox[indexPath.row].hobbyName
        cell.hobbyIcon.image = UIImage(named: hobbyBox[indexPath.row].hobbyAvatar!)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        //  最多两个爱好
        let max = 2
        if (hobbySelected.count < max) && (cell?.accessoryType == UITableViewCell.AccessoryType.none){
            cell?.accessoryType = .checkmark
            hobbySelected.append(hobbyBox[indexPath.row])
            print("selected hobby:" + hobbyBox[indexPath.row].hobbyName!)
        }
        else if cell?.accessoryType == UITableViewCell.AccessoryType.checkmark{
            cell?.accessoryType = .none
            for index in 0..<hobbySelected.count {
                if hobbyBox[indexPath.row].hobbyName == hobbySelected[index].hobbyName{
                    print("remove hobby:" + hobbySelected[index].hobbyName!)
                    hobbySelected.remove(at: index)
                    break;
                }
            }
        }
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let mainVC = segue.destination as! MainGameViewController
        var playerList = [Role]()
        if roleNameText.text == nil {
            roleNameText.text = randomName()
        }
        playerList.append(Role(name: roleNameText.text!, age: 18, sex: roleSex!, hobbies: hobbySelected))
        mainVC.roleList = playerList
        mainVC.eventCardFactory = EventCardFactory(isLoad: false)
    }
}
