//
//  SexSelectViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/19.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class SexSelectViewController: UIViewController {

    @IBOutlet weak var maleButton: UIButton!
    @IBOutlet weak var femaleButton: UIButton!
    
    @IBAction func closeButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func closeButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        ButtonTool.setButtonShadow(button: maleButton)
        ButtonTool.setButtonShadow(button: femaleButton)
        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let roleSettingVC = segue.destination as! RoleSettingViewController
        
        if segue.identifier == "maleSelected" {
            print("Selected male")
            roleSettingVC.roleSex = 1
        }
        else if segue.identifier == "femaleSelected" {
            print("Selected female")
            roleSettingVC.roleSex = 0
        }
    }
    

}
