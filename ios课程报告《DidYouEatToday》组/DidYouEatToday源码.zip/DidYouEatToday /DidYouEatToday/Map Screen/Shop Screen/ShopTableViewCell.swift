//
//  shopTableViewCell.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/10.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ShopTableViewCell: UITableViewCell {

    
    @IBOutlet weak var goodsName: UILabel!
    @IBOutlet weak var goodsIcon: UIImageView!
    @IBOutlet weak var disableMask: UIImageView!
    @IBOutlet weak var moneyValueLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
