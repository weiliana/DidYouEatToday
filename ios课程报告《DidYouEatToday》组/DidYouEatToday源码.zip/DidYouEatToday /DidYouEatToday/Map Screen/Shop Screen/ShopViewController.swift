//
//  ShopViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/10.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ShopViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var playerProperty: RoleProperty?
    var playerFactor: PropertyFactor?
    var goodsList: [Goods] = [Goods]()
    var selectedList: [Goods] = [Goods]()
    var placeName: String?
    var totalMoney: Int = 0
    var eatTime: Int = 1
    
    
    
    @IBOutlet weak var totalMoneyLabel: UILabel!
    @IBOutlet weak var pocketMoneyLabel: UILabel!
    @IBOutlet weak var backgroundImage: UIImageView!
    
    @IBOutlet weak var goodsTableView: UITableView!
    @IBOutlet weak var screenMask: UIImageView!
    @IBOutlet weak var popupView: UIView!
    @IBOutlet weak var eatingProgressBar: CustomProgressView!
    
    
    @IBAction func closeButtonUp(_ sender: UIButton) {
    }
    
    @IBAction func closeButtonDown(_ sender: UIButton) {
    }
    
    @IBAction func buyGoods(_ sender: Any) {
        if totalMoney == 0 {
            print("你还没有选择商品！")
        }
        else {
            var sumProperty = RoleProperty()
            //计算更改的属性大小
            for item in selectedList {
                sumProperty = sumProperty.apprend(property: item.property!)
                
            }
            //更改property的属性
            playerProperty = playerProperty?.apprend(property: sumProperty)
            
            if let selectedItems = goodsTableView!.indexPathsForSelectedRows {
                for indexPath in selectedItems {
                    let cell = goodsTableView.cellForRow(at: indexPath)
                    cell?.accessoryType = .none
                }
            }
            selectedList.removeAll()
            totalMoney = 0
            totalMoneyLabel.text = "0"
            pocketMoneyLabel.text = playerProperty?.PocketMoney?.description
            
            popupView.isHidden = false
            screenMask.isHidden = false
            Timer.scheduledTimer(timeInterval: TimeInterval(0.02 * Double(eatTime)), target: self, selector: #selector(inc), userInfo: nil, repeats: true)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        goodsTableView.rowHeight = 100
        
        pocketMoneyLabel.text = playerProperty?.PocketMoney?.description
        eatingProgressBar.barColor = UIColor(named: "shopBgColor")!
        
        initGoods()
        // Do any additional setup after loading the view.
    }
    
    func initGoods() {
        if placeName == "便利店" {
            goodsList.append(Goods(name:"能量饮料",energy: 20,imagepath: "",morality:0,intelligence:0,physical:0,charm:0,pocketmoney:-8))
            goodsList.append(Goods(name:"橘汁",energy: 5,imagepath: "",morality:0,intelligence:0,physical:10,charm:5,pocketmoney:-3))
            goodsList.append(Goods(name:"快餐",energy: 30,imagepath: "",morality:0,intelligence:0,physical:0,charm:5,pocketmoney:-20))
            goodsList.append(Goods(name:"牛奶",energy: 7,imagepath: "",morality:0,intelligence:8,physical:0,charm:0,pocketmoney:-5))
            goodsList.append(Goods(name:"热狗",energy: 15,imagepath: "",morality:0,intelligence:0,physical:5,charm:0,pocketmoney:-5))
        }
        else if placeName == "饭店" {
            goodsList.append(Goods(name:"牛肉火锅",energy: 36,imagepath: "",morality:10,intelligence:28,physical:42,charm:34,pocketmoney:-198))
            goodsList.append(Goods(name:"过桥米线",energy: 48,imagepath: "",morality:4,intelligence:10,physical:14,charm:10,pocketmoney:-38))
            goodsList.append(Goods(name:"猪肚鸡",energy: 60,imagepath: "",morality:8,intelligence:16,physical:24,charm:18,pocketmoney:-118))
            
            eatTime = 5
        }
        
    }
    
    
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return goodsList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "goodsCell", for: indexPath) as! ShopTableViewCell
        
        cell.goodsIcon.image = goodsList[indexPath.row].goodsIcon
        cell.goodsName.text = goodsList[indexPath.row].name
        cell.moneyValueLabel.text = (-goodsList[indexPath.row].property!.PocketMoney!).description
        if abs(goodsList[indexPath.row].property!.PocketMoney!) > playerProperty!.PocketMoney! {
            //  设置使cell无法选择
            cell.isUserInteractionEnabled = false
            cell.disableMask.isHidden = false
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        let money = playerProperty!.PocketMoney! - totalMoney
        
        if (money + goodsList[indexPath.row].property!.PocketMoney! >= 0)&&(cell?.accessoryType == UITableViewCell.AccessoryType.none){
            cell?.accessoryType = .checkmark
            selectedList.append(goodsList[indexPath.row])
            totalMoney -= goodsList[indexPath.row].property!.PocketMoney!
            print("selected goods:" + goodsList[indexPath.row].name!)
        }
        else if cell?.accessoryType == UITableViewCell.AccessoryType.checkmark{
            cell?.accessoryType = .none
            for index in 0..<selectedList.count {
                if goodsList[indexPath.row].name == selectedList[index].name{
                    print("remove goods:" + selectedList[index].name!)
                    totalMoney += selectedList[index].property!.PocketMoney!
                    selectedList.remove(at: index)
                    break;
                }
            }
        }
        totalMoneyLabel.text = totalMoney.description
    }
    
    @objc func inc(_ t: Timer) {
        // 获取当前的进度值
        var val = Float(self.eatingProgressBar.value)
        val += 0.01
        // 更新value值
        self.eatingProgressBar.value = CGFloat(val)
        self.eatingProgressBar.setNeedsDisplay()
        if val >= 1.0 {
            t.invalidate()
            popupView.isHidden = true
            screenMask.isHidden = true
            self.eatingProgressBar.value = CGFloat(0)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
