//
//  ShopViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/17.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class MapViewController: UIViewController, UITableViewDataSource {

    var playerProperty: RoleProperty?
    var playerFactor: PropertyFactor?
    var placeList: [Place]=[Place]()
    var dayTime: Int = 0
    
    @IBOutlet weak var mapTableView: UITableView!
    @IBOutlet weak var energyValueLabel: UILabel!
    @IBAction func closeButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        self.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapTableView.rowHeight = 80
        
        initMapList()
        energyValueLabel.text = playerProperty?.Energy?.description
        
        print("day time: \(dayTime)")
        // Do any additional setup after loading the view.
    }
    
    
    func initMapList() -> Void {
        //Shop.singleton.initRestaurantList()
        //ItemWarehouse.singleton.initFoodList()
        placeList.append(Place(name: "便利店", energy: -5,openTime: 17, placeAvatar: "", detial: ""))
        placeList.append(Place(name: "饭店", energy: -10,openTime: 17, placeAvatar: "", detial: ""))
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return placeList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mapCell", for: indexPath) as! MapTableViewCell
        
        cell.placeImage.image = placeList[indexPath.row].placeAvatar
        cell.placeName.text = placeList[indexPath.row].name
        cell.energyValueLabel.text = placeList[indexPath.row].energy!.description
        if (dayTime >= 22)||(placeList[indexPath.row].openTime! > dayTime)||(abs(placeList[indexPath.row].energy!) > playerProperty!.Energy!) {
            //  设置使cell无法选择
            cell.isUserInteractionEnabled = false
            cell.disableMask.isHidden = false
        }
        
        return cell
    }
    
    
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let loadVC = segue.destination as! LoadingViewController
        if let selectedCell = sender as? UITableViewCell{
            let indexPath = mapTableView.indexPath(for: selectedCell)!
            let selectPlace = placeList[(indexPath as NSIndexPath).row]
            //loadVC.currentPlace = Shop.singleton
            loadVC.place = selectPlace
            playerProperty?.Energy = (playerProperty?.Energy!)! - selectPlace.energy!
            loadVC.playerProperty = playerProperty
            loadVC.playerFactor = playerFactor
        }
    }

}
