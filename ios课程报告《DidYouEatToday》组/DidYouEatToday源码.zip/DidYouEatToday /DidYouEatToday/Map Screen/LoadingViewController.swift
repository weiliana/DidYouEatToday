//
//  LoadingViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/10.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class LoadingViewController: UIViewController {

    var playerProperty: RoleProperty?
    var playerFactor: PropertyFactor?
    var place: Place?
    var walkTime: Int = 1
    var timer: Timer?
    
    
    @IBOutlet weak var tipsLabel: UILabel!
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var loadingProgressBar: CustomProgressView!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if place?.name == "便利店" {
            backgroundImage.image = UIImage(imageLiteralResourceName: "bg-shop")
            walkTime = 2
        } else if place?.name == "饭店" {
            walkTime = 4
        }
        
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(0.03 * Double(walkTime)), target: self, selector: #selector(inc), userInfo: nil, repeats: true)
        // Do any additional setup after loading the view.
    }
    

    @objc func inc(_ t: Timer) {
        // 获取当前的进度值
        var val = Float(self.loadingProgressBar.value)
        val += 0.01
        //setActivityDetail(index: Int(val * Float(activityCount!)))
        // 更新value值
        self.loadingProgressBar.value = CGFloat(val)
        self.loadingProgressBar.setNeedsDisplay()
        if val >= 1.0 {
            t.invalidate()
            finishLoading()
        }
    }
    
    func finishLoading() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let placeVC = storyboard.instantiateViewController(withIdentifier: "ShopPage") as! ShopViewController
        placeVC.playerFactor = playerFactor
        placeVC.playerProperty = playerProperty
        placeVC.placeName = place?.name
        self.present(placeVC, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
