//
//  MapTableViewCell.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/10.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class MapTableViewCell: UITableViewCell {

    
    @IBOutlet weak var placeName: UILabel!
    @IBOutlet weak var disableMask: UIImageView!
    @IBOutlet weak var placeImage: UIImageView!
    @IBOutlet weak var energyValueLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
