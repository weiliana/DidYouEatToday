//
//  AboutUsViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/17.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController {

    @IBOutlet weak var topImage: UIImageView!
    @IBAction func closeButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    
    @IBAction func closeButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //为图片添加阴影（透明背景）
        topImage.layer.shadowColor = UIColor.black.cgColor
        topImage.layer.shadowOffset = CGSize.init(width: 0, height: 5)  //偏移
        topImage.layer.shadowOpacity = 0.15  //透明度
        topImage.layer.shadowRadius = 7  //阴影半径
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
