//
//  ViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/17.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    var playerList: [Role] = [Role]()
    var audioPlayer: AVAudioPlayer = AVAudioPlayer()
    
    
    // 程序退出入口，用于其他界面退出后跳转
    @IBAction func exitToStartGame (segue: UIStoryboardSegue) {
        print("exitToStartGame")
        if let roleList = loadPlayerFile() {
            if roleList.count == 0 {
                continueGameButton.isHidden = true
            }
            else {
                playerList = roleList
                continueGameButton.isHidden = false
                print("continueGameButton.isHidden = false")
            }
        }
        else{
            continueGameButton.isHidden = true
        }
    }

    @IBOutlet weak var continueGameButton: UIButton!
    @IBOutlet weak var newGameButton: UIButton!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var aboutUsButton: UIButton!
    
    @IBAction func continueGameButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func continueGameButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
    }
    @IBAction func newGameButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func newGameButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
    }
    @IBAction func settingButton(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func settingButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
    }
    @IBAction func aboutButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func aboutButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let buttonRadius: CGFloat = 30.0
        
        if let roleList = loadPlayerFile() {
            if roleList.count == 0 {
                continueGameButton.isHidden = true
            }
            else {
                playerList = roleList
                continueGameButton.isHidden = false
            }
        }
        else{
            continueGameButton.isHidden = true
        }
        
        
        ButtonTool.setButtonRound(button: continueGameButton, radius: buttonRadius)
        ButtonTool.setButtonRound(button: newGameButton, radius: buttonRadius)
        ButtonTool.setButtonRound(button: settingButton, radius: buttonRadius)
        ButtonTool.setButtonRound(button: aboutUsButton, radius: buttonRadius)
        
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setActive(true)
            try session.setCategory(AVAudioSession.Category.playback)
            UIApplication.shared.beginReceivingRemoteControlEvents()
            let path = Bundle.main.path(forResource: "bgm", ofType: "mp3")
            let soudUrl = URL(fileURLWithPath: path!)
            try audioPlayer = AVAudioPlayer(contentsOf: soudUrl)
            audioPlayer.prepareToPlay()
            audioPlayer.volume = 0.4
            audioPlayer.numberOfLoops = -1
            audioPlayer.play()
            
        } catch {
            print(error)
        }
        
        
    }
    
    func loadPlayerFile() -> [Role]? {
        return (NSKeyedUnarchiver.unarchiveObject(withFile: Role.ArchiveURL.path) as? [Role])
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "StartToMain" {
            print("StartToMain")
            let mainVC = segue.destination as! MainGameViewController
            mainVC.roleList = playerList
        }
    }
}

