//
//  ActivitiesViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/17.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ActivitiesViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    var selectedActivities: [Activity] = [Activity] ()
    var playerProperty: RoleProperty?
    var playerFactor: PropertyFactor?
    var tempProperty: RoleProperty?
    
    
    let activityMax: Int = 4
    
    
    @IBOutlet weak var addActivityButton: UIButton!
    @IBOutlet weak var startActivityButton: UIButton!
    
    @IBAction func closeButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func closeButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        self.dismiss(animated: true, completion: nil)
    }
    @IBOutlet weak var activityTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.activityTableView.rowHeight = 80
        tempProperty = playerProperty?.copySelf()
        addActivityButton.isHidden = (selectedActivities.count >= activityMax)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedActivities.count
    }
    
    func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
        return "删除"
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "activityCell", for: indexPath) as! ActivityTableViewCell
        cell.activityName.text = selectedActivities[indexPath.row].name
        cell.activityIcon.image = selectedActivities[indexPath.row].activityIcon
        return cell
    }
    
    // Override to support editing the table view.
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tempProperty?.Energy! -= selectedActivities[indexPath.row].property!.Energy!
            selectedActivities.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
        addActivityButton.isHidden = (selectedActivities.count >= activityMax)
        startActivityButton.isHidden = (selectedActivities.count == 0)
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showActivityList" {
            print("showActivityList")
            let alVC = segue.destination as! ActivityListViewController
            alVC.playerEnergy = tempProperty?.Energy
        }
        else if segue.identifier == "doActivities" {
            print("doActivities")
            print("energy: \(String(describing: playerProperty?.Energy!))")
            let eveVC = segue.destination as! DoActivityViewController
            eveVC.activities = selectedActivities
            eveVC.playerProperty = playerProperty
            eveVC.playerFactor = playerFactor
        }
    }
    
    
    @IBAction func saveToActivityList(segue: UIStoryboardSegue){
        if let addActivityVC = segue.source as? ActivityListViewController{
            tempProperty?.Energy = addActivityVC.playerEnergy
            if let addActivity = addActivityVC.selectedActivity{
                selectedActivities.append(addActivity)
                let newIndexPath = IndexPath(row: selectedActivities.count-1, section: 0)
                activityTableView.insertRows(at: [newIndexPath], with: .automatic)
            }
        }
        addActivityButton.isHidden = (selectedActivities.count >= activityMax)
        startActivityButton.isHidden = (selectedActivities.count == 0)
    }
}
