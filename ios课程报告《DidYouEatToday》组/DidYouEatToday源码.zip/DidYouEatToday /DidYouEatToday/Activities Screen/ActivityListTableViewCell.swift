//
//  ActivityListTableViewCell.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/4.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ActivityListTableViewCell: UITableViewCell {
    @IBOutlet weak var activityIcon: UIImageView!
    @IBOutlet weak var activityName: UILabel!
    @IBOutlet weak var activityEnergyValue: UILabel!
    @IBOutlet weak var disableMask: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
