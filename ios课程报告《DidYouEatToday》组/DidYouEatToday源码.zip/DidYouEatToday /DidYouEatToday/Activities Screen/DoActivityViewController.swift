//
//  EventsViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/17.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ButtonDetail {
    var type: Int = 0
    var color: String = ""
    init(type: Int, color: String) {
        self.type = type
        self.color = color
    }
}

class DoActivityViewController: UIViewController {
    
    var activities: [Activity]?
    var playerProperty: RoleProperty?
    var playerFactor: PropertyFactor?
    
    var timer: Timer?
    var activityCount: Int?
    var clickTimes: Float = 1.0
    var isClick = false
    var isUp: [Bool] = [Bool](repeating: false, count: 9)
    var playButton: [UIButton] = [UIButton]()
    var allButtonDetail: [ButtonDetail] = [ButtonDetail]()
    var currentButtonDetail: [ButtonDetail] = [ButtonDetail]()
    let maxSpeed: Float = 4.0
    
    var Intelligence: Int = 0
    var Physics: Int = 0
    var Morality: Int = 0
    var Charm: Int = 0

    @IBOutlet weak var activityProgressBar: CustomProgressView!
    @IBOutlet weak var activityNameLabel: UILabel!
    @IBOutlet weak var activityImage: UIImageView!
    @IBOutlet weak var sumReportView: UIView!
    
    @IBOutlet weak var moralityScoreLabel: UILabel!
    @IBOutlet weak var intelligenceScoreLabel: UILabel!
    @IBOutlet weak var physcicsScoreLabel: UILabel!
    @IBOutlet weak var charmScoreLabel: UILabel!
    @IBOutlet weak var scoreBoardView: UIStackView!
    
    @IBOutlet weak var energyLabel: UILabel!
    @IBOutlet weak var pocketMoneyLabel: UILabel!
    @IBOutlet weak var moralityValueLabel: UILabel!
    @IBOutlet weak var intelligenceValueLabel: UILabel!
    @IBOutlet weak var physicalValueLabel: UILabel!
    @IBOutlet weak var charmValueLabel: UILabel!
    
    @IBOutlet weak var playButton0: UIButton!
    @IBOutlet weak var playButton1: UIButton!
    @IBOutlet weak var playButton2: UIButton!
    @IBOutlet weak var playButton3: UIButton!
    @IBOutlet weak var playButton4: UIButton!
    @IBOutlet weak var playButton5: UIButton!
    @IBOutlet weak var playButton6: UIButton!
    @IBOutlet weak var playButton7: UIButton!
    @IBOutlet weak var playButton8: UIButton!
    
    @IBAction func playButton0Up(_ sender: UIButton) {
    }
    @IBAction func playButton0Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 0)
    }
    @IBAction func playButton1Up(_ sender: UIButton) {
    }
    @IBAction func playButton1Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 1)
    }
    @IBAction func playButton2Up(_ sender: UIButton) {
    }
    @IBAction func playButton2Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 2)
    }
    @IBAction func playButton3Up(_ sender: UIButton) {
    }
    @IBAction func playButton3Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 3)
    }
    @IBAction func playButton4Up(_ sender: UIButton) {
    }
    @IBAction func playButton4Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 4)
    }
    @IBAction func playButton5Up(_ sender: UIButton) {
    }
    @IBAction func playButton5Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 5)
    }
    @IBAction func playButton6Up(_ sender: UIButton) {
    }
    @IBAction func playButton6Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 6)
    }
    @IBAction func playButton7Up(_ sender: UIButton) {
    }
    @IBAction func playButton7Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 7)
    }
    @IBAction func playButton8Up(_ sender: UIButton) {
    }
    @IBAction func playButton8Down(_ sender: UIButton) {
        buttonDown(sender: sender, number: 8)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activityCount = activities?.count
        scoreBoardView.isHidden = false
        //  设置总进度条的初始值
        self.activityProgressBar.value = 0.0
        self.activityProgressBar.setNeedsDisplay()
        //  将棋盘的所有按钮存入按钮数组，方便使用
        playButton.append(playButton0)
        playButton.append(playButton1)
        playButton.append(playButton2)
        playButton.append(playButton3)
        playButton.append(playButton4)
        playButton.append(playButton5)
        playButton.append(playButton6)
        playButton.append(playButton7)
        playButton.append(playButton8)
        //  初始化类型-颜色基本数组，用于随机按钮类型
        allButtonDetail.append(ButtonDetail(type: 0, color: "moralityColor"))
        allButtonDetail.append(ButtonDetail(type: 1, color: "intelligenceColor"))
        allButtonDetail.append(ButtonDetail(type: 2, color: "physicsColor"))
        allButtonDetail.append(ButtonDetail(type: 3, color: "charmColor"))
        
        setActivityDetail(index: 0)
        randomPlayboard()
        //  总活动时间计时器
        Timer.scheduledTimer(timeInterval: TimeInterval(0.4), target: self, selector: #selector(inc), userInfo: nil, repeats: true)
        
        setButtonHideClock()
    }
    
    
    func buttonDown(sender: UIButton, number: Int) {
        var value = 0
        //  判断所点击的按钮是否为上
        if isUp[number] {
            clickTimes += 0.02
            value = 1
        }
        else {
            value = -1
        }
        //  判断按钮类型
        switch currentButtonDetail[number].type {
        case 0:
            Morality += value
            moralityScoreLabel.text = Morality.description
        case 1:
            Intelligence += value
            intelligenceScoreLabel.text = Intelligence.description
        case 2:
            Physics += value
            physcicsScoreLabel.text = Physics.description
        case 3:
            Charm += value
            charmScoreLabel.text = Charm.description
        default:
            break
        }
        isClick = true
        //  提前终止显示计时器，进入过渡计时器
        timer?.invalidate()
        transitionSection()
    }
    
    @objc func inc(_ t: Timer) {
        // 获取当前的进度值
        var val = Float(self.activityProgressBar.value)
        val += (0.01 / Float(activityCount!))
        setActivityDetail(index: Int(val * Float(activityCount!)))
        // 更新value值
        self.activityProgressBar.value = CGFloat(val)
        self.activityProgressBar.setNeedsDisplay()
        if val >= 1.0 {
            t.invalidate()
            
        }
    }
    //  设置当前活动的所有属性
    func setActivityDetail(index: Int) {
        activityNameLabel.text = activities![min(index, activityCount!-1)].name
    }
    
    
    @objc func buttonHideClock(_ t: Timer) {
        transitionSection()
    }
    
    @objc func buttonShowClock(_ t: Timer) {
        randomPlayboard()
        setButtonHideClock()
    }
    //  过渡阶段计时器动画
    func transitionSection() {
        setBoardHide()
        //  获取当前的进度值
        let val = Float(self.activityProgressBar.value)
        if val < 1.0 {
            Timer.scheduledTimer(timeInterval: TimeInterval(0.3), target: self, selector: #selector(buttonShowClock), userInfo: nil, repeats: false)
        }
        else {
            finishActivity()
        }
    }
    //  按钮显示多长时间后执行隐藏按钮函数的计时器
    func setButtonHideClock() {
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(3.0 / min(clickTimes, maxSpeed)), target: self, selector: #selector(buttonHideClock), userInfo: nil, repeats: false)
    }
    //  设置棋盘所有按钮隐藏
    func setBoardHide() {
        for button in playButton {
            ButtonTool.setButtonDisappear(sender: button)
        }
        //  玩家不点击时判断为点错状态
        if !isClick {
            isClick = true
            let value = -1
            let type = randomNumber(to: 4)
            switch type {
            case 0:
                Morality += value
                moralityScoreLabel.text = Morality.description
            case 1:
                Intelligence += value
                intelligenceScoreLabel.text = Intelligence.description
            case 2:
                Physics += value
                physcicsScoreLabel.text = Physics.description
            case 3:
                Charm += value
                charmScoreLabel.text = Charm.description
            default:
                break
            }
        }
 
        
    }
    
    //  随机设置棋盘
    func randomPlayboard() {
        var up: [Int] = [Int]()
        let upMaxCount = 3
        //  初始化所有按钮为向下
        for index in 0..<isUp.count {
            isUp[index] = false
        }
        //  随机选择向上按钮
        for _ in 0..<upMaxCount {
            let index = randomNumber(to: isUp.count)
            up.append(index)
            isUp[index] = true
        }
        setBoard(up: up)
        isClick = false
    }
    
    func setBoard(up: [Int]) {
        let downImage = UIImage(named: "icon-down-arrow")
        let upImage = UIImage(named: "icon-up-arrow")
        
        //  清空当前按钮类型属性缓存
        currentButtonDetail.removeAll()
        //  随机设置按钮的类型属性并存入数组
        for button in playButton {
            let detail = allButtonDetail.randomElement()!
            currentButtonDetail.append(detail)
            button.setImage(downImage, for: UIControl.State.normal)
            button.backgroundColor = UIColor(named: detail.color)
        }
        //  设置向上按钮
        for index in up {
            playButton[index].setImage(upImage, for: UIControl.State.normal)
        }
        //  显示所有按钮
        for button in playButton {
            button.isHidden = false
            ButtonTool.setButtonAppear(sender: button)
        }
        
    }
    
    
    
    //  所有活动结束后计算并显示总结面板
    func finishActivity() {
        activityImage.isHidden = true
        scoreBoardView.isHidden = true
        
        var sumProperty = RoleProperty()
        //计算更改的属性大小
        for item in activities! {
            sumProperty = sumProperty.apprend(property: item.property!)
        }
        sumProperty.Morality = sumProperty.Morality! + Morality
        sumProperty.Intelligence = sumProperty.Intelligence! + Intelligence
        sumProperty.Physical = sumProperty.Physical! + Physics
        sumProperty.Charm = sumProperty.Charm! + Charm
        sumProperty.multiplyFactor(factor: playerFactor!)
        
        //赋值给label
        energyLabel.text = ((sumProperty.Energy!>0) ? "+":"") + sumProperty.Energy!.description
        pocketMoneyLabel.text = ((sumProperty.PocketMoney!>0) ? "+":"") + sumProperty.PocketMoney!.description
        moralityValueLabel.text = ((sumProperty.Morality!>0) ? "+":"") + sumProperty.Morality!.description
        intelligenceValueLabel.text = ((sumProperty.Intelligence!>0) ? "+":"") + sumProperty.Intelligence!.description
        physicalValueLabel.text = ((sumProperty.Physical!>0) ? "+":"") + sumProperty.Physical!.description
        charmValueLabel.text = ((sumProperty.Charm!>0) ? "+":"") + sumProperty.Charm!.description
        
        //更改property的属性
        playerProperty = playerProperty?.apprend(property: sumProperty)        
        
        sumReportView.isHidden = false
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    //  生成范围随机数并返回
    func randomNumber(from: Int = 0, to: Int) -> Int {
        var result = 0
        let scope = to - from
        result = Int(arc4random_uniform(UInt32(scope))) + from
        return result
    }
    
}
