//
//  ActivityListViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/4.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class ActivityListViewController: UIViewController, UITableViewDataSource {
    
    var selectList = [Activity] ()
    var selectedActivity: Activity?
    var playerEnergy: Int?

    
    @IBOutlet weak var energyValueLabel: UILabel!
    @IBOutlet weak var activitylistTableView: UITableView!
    
    
    @IBAction func backButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activitylistTableView.rowHeight = 80
        energyValueLabel.text = playerEnergy?.description
        initSelectList()
    }
    
    func initSelectList(){
        selectList.append(Activity(name:"学习",energy: -20,imagepath: "",morality:15,intelligence:30,physical:5,charm:10,pocketmoney:0))
        selectList.append(Activity(name:"运动",energy: -15,imagepath: "",morality:20,intelligence:5,physical:30,charm:20,pocketmoney:0))
        selectList.append(Activity(name:"娱乐",energy: -10,imagepath: "",morality:10,intelligence:5,physical:5,charm:30,pocketmoney:0))
        selectList.append(Activity(name:"休闲",energy: -5,imagepath: "",morality:10,intelligence:10,physical:10,charm:10,pocketmoney:0))
        selectList.append(Activity(name:"工作",energy: -30,imagepath: "",morality:15,intelligence:15,physical:10,charm:15,pocketmoney:50))
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectList.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "activitylistCell", for: indexPath) as! ActivityListTableViewCell
        cell.activityName.text = selectList[indexPath.row].name
        cell.activityEnergyValue.text = selectList[indexPath.row].property!.Energy!.description
        cell.activityIcon.image = selectList[indexPath.row].activityIcon
        if abs(selectList[indexPath.row].property!.Energy!) > playerEnergy! {
            //  设置使cell无法选择
            print("设置使cell无法选择")
            cell.isUserInteractionEnabled = false
            cell.disableMask.isHidden = false
        }
        return cell
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let selectedCell = sender as? ActivityListTableViewCell{
            let indexPath = activitylistTableView.indexPath(for: selectedCell)!
            selectedActivity = selectList[(indexPath as NSIndexPath).row]
            playerEnergy! += (selectedActivity?.property!.Energy!)!
        }
    }

}
