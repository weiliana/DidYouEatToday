//
//  StatusViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/12.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class StatusViewController: UIViewController {
    var player: Role?
    
    @IBOutlet weak var roleImage: UIImageView!
    @IBOutlet weak var roleNameLabel: UILabel!
    @IBOutlet weak var roleSexIcon: UIImageView!
    @IBOutlet weak var roleHobbyLabel: UILabel!
    @IBOutlet weak var energyLabel: UILabel!
    @IBOutlet weak var pocketMoneyLabel: UILabel!
    @IBOutlet weak var intelligentLabel: UILabel!
    @IBOutlet weak var physicsLabel: UILabel!
    @IBOutlet weak var moralityLabel: UILabel!
    @IBOutlet weak var charmLabel: UILabel!
    
    @IBAction func closeButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
    }
    @IBAction func closeButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        setupRoleStatus()
        // Do any additional setup after loading the view.
    }
    
    func setupRoleStatus() {
        if player?.mySex == 0 {
            //  female
            roleImage.image = UIImage(named: "icon-button-female")
            roleSexIcon.image = UIImage(named: "female-symbol")
        }
        else {
            roleImage.image = UIImage(named: "icon-button-male")
            roleSexIcon.image = UIImage(named: "male-symbol")
        }
        roleNameLabel.text = player?.myName
        roleHobbyLabel.text = player?.getHobbyName()
        energyLabel.text = player?.myProperty?.Energy?.description
        pocketMoneyLabel.text = player?.myProperty?.PocketMoney?.description
        intelligentLabel.text = player?.myProperty?.Intelligence?.description
        physicsLabel.text = player?.myProperty?.Physical?.description
        moralityLabel.text = player?.myProperty?.Morality?.description
        charmLabel.text = player?.myProperty?.Charm?.description
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
