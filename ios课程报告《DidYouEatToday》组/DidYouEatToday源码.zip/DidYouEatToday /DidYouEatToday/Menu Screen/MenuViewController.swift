//
//  MenuViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/2.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController {
    
    var player: Role?

    let transitionManager = TransitionManager()
    
    // MARK: - IBOutlets
    
    @IBOutlet weak var goodsButton: UIButton!
    @IBOutlet weak var goodsLabel: UILabel!
    
    @IBOutlet weak var relationshipButton: UIButton!
    @IBOutlet weak var relationshipLabel: UILabel!
    
    @IBOutlet weak var mailButton: UIButton!
    @IBOutlet weak var mailLabel: UILabel!
    
    @IBOutlet weak var achievementButton: UIButton!
    @IBOutlet weak var achievementLabel: UILabel!
    
    @IBAction func closeButtonUp(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.transitioningDelegate = self.transitionManager
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showStatus" {
            print("showStatus")
            let statusVC = segue.destination as! StatusViewController
            statusVC.player = player
        }
    }
    

}
