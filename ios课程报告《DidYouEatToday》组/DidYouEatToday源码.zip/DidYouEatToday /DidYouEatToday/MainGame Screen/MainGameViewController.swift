//
//  MainGameViewController.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/17.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class MainGameViewController: UIViewController {
    let transitionManager = TransitionManager()
    
    var roleList: [Role] = [Role]()
    
    //var player: Role?
    var eventCardFactory: EventCardFactory?
    var card: EventCard?
    var dayTime: Int = 7
    var isGameOver: Bool = false
    
    
    @IBOutlet weak var schoolDateText: UILabel!
    @IBOutlet weak var seasonText: UILabel!
    @IBOutlet weak var seasonImage: UIImageView!
    @IBOutlet weak var energyValueText: UILabel!
    @IBOutlet weak var topbarImage: UIImageView!
    @IBOutlet weak var actionButton: UIButton!
    @IBOutlet weak var actionLabel: UILabel!
    
    @IBOutlet weak var screenMask: UIImageView!
    @IBOutlet weak var eventCardView: UIView!
    @IBOutlet weak var eventImage: UIImageView!
    @IBOutlet weak var eventDetailText: UITextView!
    @IBOutlet weak var leftButton: UIButton!
    @IBOutlet weak var rightButton: UIButton!
    
    
    @IBOutlet weak var resultCardView: UIView!
    @IBOutlet weak var resultImage: UIImageView!
    @IBOutlet weak var resultLabel: UITextView!
    @IBOutlet weak var resultButton: UIButton!
    @IBOutlet weak var gameOverButton: UIButton!
    
    
    @IBOutlet weak var sleepView: UIView!
    @IBOutlet weak var sleepProgressBar: CustomProgressView!
    
    // 程序退出入口，用于其他界面退出后跳转
    @IBAction func exitToMainGame (segue: UIStoryboardSegue) {
        
    }
    //  从做活动中返回
    @IBAction func finishActivityToMain (segue: UIStoryboardSegue) {
        if let eveVC = segue.source as? DoActivityViewController{
            if let property = eveVC.playerProperty{
                roleList[0].myProperty = property
                showDate()
            }
        }
        dayTime = 18
        roleList[0].printDetail()
        updateActionButton()
    }
    //  从商店中返回
    @IBAction func goBackToMain (segue: UIStoryboardSegue){
        print("go back to main")
        if let shopVC = segue.source as? ShopViewController{
            if let property = shopVC.playerProperty{
                roleList[0].myProperty = property
                showDate()
            }
        }
        dayTime += 1
        roleList[0].printDetail()
        updateActionButton()
    }
    
    
    @IBAction func mapButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
    }
    @IBAction func mapButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    
    @IBAction func actionButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        if dayTime < 18 {
            //  活动
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let activityVC = storyboard.instantiateViewController(withIdentifier: "ActivityPage") as! ActivitiesViewController
            activityVC.playerProperty = roleList[0].myProperty?.copySelf()
            activityVC.playerFactor = roleList[0].myFactor?.copySelf()
            self.present(activityVC, animated: true, completion: nil)
        }
        else {
            //  睡觉
            goToSleep()
        }
    }
    @IBAction func actionButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func luggageButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
    }
    @IBAction func luggageButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    
    @IBAction func leftButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        roleList[0].myProperty = roleList[0].myProperty?.apprend(property: card!.eventLeftProperty!)
        hideEventCard()
        if isGameOver {
            roleList.removeAll()
            savePlayerFile()
            resultButton.isHidden = true
            gameOverButton.isHidden = false
        }
        else {
            resultButton.isHidden = false
            gameOverButton.isHidden = true
        }
        resultLabel.text = card?.eventLeftResult
        showResultCard()
    }
    @IBAction func leftButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    @IBAction func rightButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        roleList[0].myProperty = roleList[0].myProperty?.apprend(property: card!.eventRightProperty!)
        hideEventCard()
        if isGameOver {
            roleList.removeAll()
            savePlayerFile()
            resultButton.isHidden = true
            gameOverButton.isHidden = false
        }
        else {
            resultButton.isHidden = false
            gameOverButton.isHidden = true
        }
        resultLabel.text = card?.eventRightResult
        showResultCard()
    }
    @IBAction func rightButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    
    
    @IBAction func resultButtonUp(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: false)
        hideResultCard()
    }
    @IBAction func resultButtonDown(_ sender: UIButton) {
        ButtonTool.setButtonAnimaton(sender: sender, isDown: true)
    }
    
    func hideEventCard() {
        screenMask.isHidden = true
        eventCardView.isHidden = true
    }
    
    func showResultCard() {
        screenMask.isHidden = false
        resultCardView.isHidden = false
    }
    
    func hideResultCard() {
        screenMask.isHidden = true
        resultCardView.isHidden = true
    }
    
    
    @objc func inc(_ t: Timer) {
        // 获取当前的进度值
        var val = Float(self.sleepProgressBar.value)
        val += 0.01
        // 更新value值
        self.sleepProgressBar.value = CGFloat(val)
        self.sleepProgressBar.setNeedsDisplay()
        if val >= 1.0 {
            t.invalidate()
            updateActionButton()
            showDate()
            sleepView.isHidden = true
            showEventCard()
            self.sleepProgressBar.value = CGFloat(0)
        }
    }
    
    func showEventCard() {
        screenMask.isHidden = false
        eventCardView.isHidden = false
        eventImage.image = card?.eventAvatar
        eventDetailText.text = card?.eventDescription
        leftButton.titleLabel?.text = card?.eventSelectLeft
        rightButton.titleLabel?.text = card?.eventSelectRight
    }
    
    
    func updateActionButton() {
        if dayTime < 18 {
            actionButton.setImage(UIImage(named: "icon-clipboard"), for: UIControl.State.normal)
            actionLabel.text = "今日活动"
        }
        else {
            //  睡觉
            actionButton.setImage(UIImage(named: "icon-sleep"), for: UIControl.State.normal)
            actionLabel.text = "进入梦乡"
        }
    }
    
    func goToSleep() {
        dayTime = 7
        let isGraduate = roleList[0].myLiveDay!.addDay()
        let isHungery = roleList[0].addRoleEnergyValue(value: -5)
        
        if isHungery {
            card = eventCardFactory?.takeHospitalCard()
        }
        else if ((roleList[0].myProperty!.Energy)! < 5)&&((roleList[0].myProperty!.PocketMoney)! <= 0){
            card = eventCardFactory?.takeStarveCard()
            isGameOver = true
        }
        else if isGraduate {
            card = eventCardFactory?.takeGraduateCard(roleProperty: roleList[0].myProperty!)
            isGameOver = true
        }
        else{
            card = eventCardFactory?.takeCard()
        }
        
        savePlayerFile()
        sleepView.isHidden = false
        screenMask.isHidden = false
        Timer.scheduledTimer(timeInterval: TimeInterval(0.05), target: self, selector: #selector(inc), userInfo: nil, repeats: true)
        print(roleList[0].myLiveDay!.getDate())
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //player = roleList[0]
        sleepProgressBar.barColor = UIColor(named: "nightColor")!
        eventCardFactory = EventCardFactory(isLoad: true)
        
        
        showDate()
        roleList[0].printDetail()
        
        savePlayerFile()
        // Do any additional setup after loading the view.
    }
    
    func showDate() {
        schoolDateText.text = roleList[0].myLiveDay!.getDate()
        let season = roleList[0].myLiveDay!.getSeason()
        seasonText.text = season
        energyValueText.text = roleList[0].myProperty?.Energy?.description
        switch season {
        case "春":
            seasonImage.image = UIImage(named: "icon-season-spring")
            seasonText.backgroundColor = UIColor(named: "springColor")
        case "夏":
            seasonImage.image = UIImage(named: "icon-season-summer")
            seasonText.backgroundColor = UIColor(named: "summerColor")
        case "秋":
            seasonImage.image = UIImage(named: "icon-season-fall")
            seasonText.backgroundColor = UIColor(named: "fallColor")
        case "冬":
            seasonImage.image = UIImage(named: "icon-season-winter")
            seasonText.backgroundColor = UIColor(named: "winterColor")
        default: break
            
        }
        
    }

    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showSetting" {
            print("showSetting")
            let settingVC = segue.destination as! SettingViewController
            settingVC.showExitButton = true
        }
        else if segue.identifier == "showMenu" {
            print("showMenu")
            let menuVC = segue.destination as! MenuViewController
            menuVC.player = roleList[0]
        }
        
        else if segue.identifier == "showMap" {
            print("showMap")
            let mapVC = segue.destination as! MapViewController
            //  直接同步数据
            mapVC.playerProperty = roleList[0].myProperty
            mapVC.playerFactor = roleList[0].myFactor
            mapVC.dayTime = dayTime
        }
    }
    
    func savePlayerFile(){
        let success = NSKeyedArchiver.archiveRootObject(roleList, toFile: Role.ArchiveURL.path)
        if !success {
            print("save failed")
        }
    }
    
    func loadPlayerFile() -> [Role]? {
        return (NSKeyedUnarchiver.unarchiveObject(withFile: Role.ArchiveURL.path) as? [Role])
    }

}
