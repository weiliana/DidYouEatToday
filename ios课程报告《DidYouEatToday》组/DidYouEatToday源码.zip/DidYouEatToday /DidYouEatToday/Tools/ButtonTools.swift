//
//  ButtonTools.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/26.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation
import UIKit

class ButtonTool {
    // 设置按钮圆角
    static func setButtonRound(button: UIButton, radius: CGFloat) {
        //button.layer.masksToBounds = true
        button.layer.cornerRadius = radius
        setButtonShadow(button: button)
    }
    //  设置按钮阴影
    static func setButtonShadow(button: UIButton) {
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize.init(width: 1, height: 1)  //偏移
        button.layer.shadowOpacity = 0.2  //透明度
        button.layer.shadowRadius = 10  //阴影半径
    }
    //  设置按钮点击动画
    static func setButtonAnimaton(sender: UIButton, isDown: Bool) {
        var scaleFactor: CGFloat = 1.0
        if isDown {
            scaleFactor = 1.1
        }
        UIView.animateKeyframes(withDuration: 0.1, delay: 0, options: UIView.KeyframeAnimationOptions(rawValue: 0), animations: {
            sender.transform = CGAffineTransform(scaleX: scaleFactor, y: scaleFactor)
        }) { (true) in
        }
    }
    static func setButtonDisappear(sender: UIButton, scaleFactor: CGFloat = 0.5, time: Double = 0.1) {
        UIView.animateKeyframes(withDuration: time, delay: 0, options: UIView.KeyframeAnimationOptions(rawValue: 0), animations: {
            sender.transform = CGAffineTransform(scaleX: scaleFactor, y: scaleFactor)
        }) { (isFinish) in
            if isFinish {
                // 消失
                sender.isHidden = true
            }
        }
    }
    static func setButtonAppear(sender: UIButton, scaleFactor: CGFloat = 1, time: Double = 0.1) {
        UIView.animateKeyframes(withDuration: time, delay: 0, options: UIView.KeyframeAnimationOptions(rawValue: 0), animations: {
            sender.transform = CGAffineTransform(scaleX: scaleFactor, y: scaleFactor)
        }) { (isFinish) in
            if isFinish {
                // 消失
                //sender.isHidden = true
            }
        }
    }
}
