//
//  CustomProgressView.swift
//  DidYouEatToday
//
//  Created by Link on 2019/12/8.
//  Copyright © 2019 Link. All rights reserved.
//

import UIKit

class CustomProgressView: UIView {
    // 模拟progress属性 取值范围0.0-1.0
    var value: CGFloat = 0.0
    var bgColor: UIColor = UIColor.white
    var barColor: UIColor = UIColor(named: "defaultBackgroundColorLight")!
    
    
    
    override func draw(_ rect: CGRect) {
        drawProgress(color: bgColor, ins: 0, progressValue: 1.0)
        drawProgress(color: barColor, ins: 4, progressValue: value)
    }
    
    func drawProgress(color: UIColor, ins: CGFloat, progressValue: CGFloat) {
        let c = UIGraphicsGetCurrentContext()!
        color.set() // 设置进度条的背景色
        // 设置绘制区域 在原UIView尺寸的基础上向内缩 ins points
        let r = self.bounds.insetBy(dx: ins, dy: ins)
        // 2头圆弧的半径
        let radius: CGFloat = r.size.height / 2
        let d90 = CGFloat.pi / 2
        
        // 绘制路径
        let path = CGMutablePath()
        path.move(to: CGPoint(x: r.maxX - radius, y: ins))
        path.addArc(center: CGPoint(x: radius+ins, y: radius+ins), radius: radius, startAngle: -d90, endAngle: d90, clockwise: true)
        path.addArc(center: CGPoint(x: r.maxX - radius, y: radius + ins), radius: radius, startAngle: d90, endAngle: -d90, clockwise: true)
        path.closeSubpath()
        c.addPath(path)
        c.setLineWidth(0)
        c.strokePath()
        c.addPath(path)
        c.clip()
        c.fill(CGRect(x: r.origin.x, y: r.origin.y, width: r.width * progressValue, height: r.height))
    }
    
    

}
