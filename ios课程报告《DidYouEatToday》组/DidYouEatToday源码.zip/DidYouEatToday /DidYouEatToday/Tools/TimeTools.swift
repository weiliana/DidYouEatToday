//
//  TimeTools.swift
//  DidYouEatToday
//
//  Created by Link on 2019/11/30.
//  Copyright © 2019 Link. All rights reserved.
//

import Foundation

class SchoolTime: NSObject, NSCoding {
    var year: Int?
    var season: Int?
    var date: Int?
    var totalDay:Int?
    var seasonName:String = "秋"
    
    // 秋季星期四开始
    override init() {
        totalDay = 1
        year = 1 + (2 + totalDay!/14)/4
        season = (2 + totalDay!/14)%4    //两个星期一季节
        date = (2 + totalDay!)%7
    }
    func encode(with aCoder: NSCoder) {
        aCoder.encode(year, forKey: "year")
        aCoder.encode(season, forKey: "season")
        aCoder.encode(date, forKey: "date")
        aCoder.encode(totalDay, forKey: "totalDay")
    }
    required init?(coder aDecoder: NSCoder) {
        year = aDecoder.decodeObject(forKey: "year") as? Int
        season = aDecoder.decodeObject(forKey: "season") as? Int
        date = aDecoder.decodeObject(forKey: "date") as? Int
        totalDay = aDecoder.decodeObject(forKey: "totalDay") as? Int
    }
    
    func addDay(count: Int = 1) -> Bool {
        totalDay =  totalDay! + count
        year = 1 + (2 + totalDay!/14)/4
        season = (2 + totalDay!/14)%4    //两个星期一季节
        date = (2 + totalDay!)%7
        
        switch season {
        case 0:
            seasonName = "春"
            
        case 1:
            seasonName = "夏"
            
        case 2:
            seasonName = "秋"
            
        case 3:
            seasonName = "冬"
        default:break
        }
        if totalDay! >= 10 {
            return true
        }
        return false
    }
    
    func getSeason() -> String {
        return seasonName
    }

    func getDate() -> String {
        var dayName:String = ""
        switch date {
        case 0:
            dayName = "一"
        case 1:
            dayName = "二"
        case 2:
            dayName = "三"
        case 3:
            dayName = "四"
        case 4:
            dayName = "五"
        case 5:
            dayName = "六"
        case 6:
            dayName = "日"
        default: break
        }
        return "第 \(year!) 年 周\(dayName)"
    }
    
    // 获取根目录
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    // 增加子目录
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("schoolTime")
}

